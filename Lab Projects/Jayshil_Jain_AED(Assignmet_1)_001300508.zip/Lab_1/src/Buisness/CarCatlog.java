/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Buisness;

import java.awt.Image;

/**
 *
 * @author welcome
 */
public class CarCatlog {
    private String model;
    private String color;
    private String production_year;
    private String seating_capacity;

    private String serial_num;
    private String horizontal_length;
    private String vertical_length;
    private String ground_clearence;
    
    private String fuel_type;
    private String transmission_type;
    private String safety_rating;
    private String milege;
    
    private String top_speed;
    private String engine_type;
    private String num_airbags;
    private String fueltank;
    
    private String price;
    private Image carImageUpload;

    public Image getCarImageUpload() {
        return carImageUpload;
    }

    public void setCarImageUpload(Image carImageUpload) {
        this.carImageUpload = carImageUpload;
    }

   

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getProduction_year() {
        return production_year;
    }

    public void setProduction_year(String production_year) {
        this.production_year = production_year;
    }

    public String getSeating_capacity() {
        return seating_capacity;
    }

    public void setSeating_capacity(String seating_capacity) {
        this.seating_capacity = seating_capacity;
    }

    public String getFuel_type() {
        return fuel_type;
    }

    public void setFuel_type(String fuel_type) {
        this.fuel_type = fuel_type;
    }

    public String getTransmission_type() {
        return transmission_type;
    }

    public void setTransmission_type(String transmission_type) {
        this.transmission_type = transmission_type;
    }

    public String getSafety_rating() {
        return safety_rating;
    }

    public void setSafety_rating(String safety_rating) {
        this.safety_rating = safety_rating;
    }

    public String getMilege() {
        return milege;
    }

    public void setMilege(String milege) {
        this.milege = milege;
    }

    public String getTop_speed() {
        return top_speed;
    }

    public void setTop_speed(String top_speed) {
        this.top_speed = top_speed;
    }

    public String getEngine_type() {
        return engine_type;
    }

    public void setEngine_type(String engine_type) {
        this.engine_type = engine_type;
    }

    public String getNum_airbags() {
        return num_airbags;
    }

    public void setNum_airbags(String num_airbags) {
        this.num_airbags = num_airbags;
    }

    public String getFueltank() {
        return fueltank;
    }

    public void setFueltank(String fueltank) {
        this.fueltank = fueltank;
    }
    
    
    

    public String getGround_clearence() {
        return ground_clearence;
    }

    public void setGround_clearence(String ground_clearence) {
        this.ground_clearence = ground_clearence;
    }
    
    public String getHorizontal_length() {
        return horizontal_length;
    }

    public void setHorizontal_length(String horizontal_length) {
        this.horizontal_length = horizontal_length;
    }

    public String getVertical_length() {
        return vertical_length;
    }

    public void setVertical_length(String vertical_length) {
        this.vertical_length = vertical_length;
    }

  

    public String getSerial_num() {
        return serial_num;
    }

    public void setSerial_num(String serial_num) {
        this.serial_num = serial_num;
    }



    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }


    
}
